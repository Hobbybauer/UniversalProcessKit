-- by mor2000

--------------------
-- Activator

UPK_Activator={}
local UPK_Activator_mt = ClassUPK(UPK_Activator,UniversalProcessKit)
InitObjectClass(UPK_Activator, "UPK_Activator")
UniversalProcessKit.addModule("activator",UPK_Activator)
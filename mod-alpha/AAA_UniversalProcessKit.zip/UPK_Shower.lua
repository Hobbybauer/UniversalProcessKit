-- by mor2000

--------------------
-- Shower

UPK_Shower={}
local UPK_Shower_mt = ClassUPK(UPK_Shower,UniversalProcessKit)
InitObjectClass(UPK_Shower, "UPK_Shower")
UniversalProcessKit.addModule("shower",UPK_Shower)
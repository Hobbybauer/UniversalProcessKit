-- by mor2000

--------------------
-- Shower

UPK_Scaler={}
local UPK_Scaler_mt = ClassUPK(UPK_Scaler,UniversalProcessKit)
InitObjectClass(UPK_Scaler, "UPK_Scaler")
UniversalProcessKit.addModule("scaler",UPK_Scaler)
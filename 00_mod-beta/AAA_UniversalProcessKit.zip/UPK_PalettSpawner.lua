-- by mor2000

--------------------
-- PalettSpawner


local UPK_PalettSpawner_mt = ClassUPK(UPK_PalettSpawner,UniversalProcessKit)
InitObjectClass(UPK_PalettSpawner, "UPK_PalettSpawner")
UniversalProcessKit.addModule("palettspawner",UPK_PalettSpawner)
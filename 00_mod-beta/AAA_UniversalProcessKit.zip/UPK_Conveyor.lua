-- by mor2000

--------------------
-- Conveyor


local UPK_Conveyor_mt = ClassUPK(UPK_Conveyor,UniversalProcessKit)
InitObjectClass(UPK_Conveyor, "UPK_Conveyor")
UniversalProcessKit.addModule("conveyor",UPK_Conveyor)
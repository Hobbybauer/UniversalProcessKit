-- by mor2000

--------------------
-- Shower


local UPK_Shower_mt = ClassUPK(UPK_Shower,UniversalProcessKit)
InitObjectClass(UPK_Shower, "UPK_Shower")
UniversalProcessKit.addModule("shower",UPK_Shower)
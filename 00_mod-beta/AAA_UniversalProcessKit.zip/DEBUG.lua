-- by mor2000

debugMode=true -- DEBUG (print a lot of messages to log)



-- by mor2000

debugMode=false -- DEBUG (print a lot of messages to log)



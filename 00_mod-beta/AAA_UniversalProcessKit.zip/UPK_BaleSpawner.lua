-- by mor2000

--------------------
-- BaleSpawner


local UPK_BaleSpawner_mt = ClassUPK(UPK_BaleSpawner,UniversalProcessKit)
InitObjectClass(UPK_BaleSpawner, "UPK_BaleSpawner")
UniversalProcessKit.addModule("balespawner",UPK_BaleSpawner)
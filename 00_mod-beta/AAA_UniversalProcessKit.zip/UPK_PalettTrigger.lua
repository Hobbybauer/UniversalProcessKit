-- by mor2000

--------------------
-- PalettTrigger


local UPK_PalettTrigger_mt = ClassUPK(UPK_PalettTrigger,UniversalProcessKit)
InitObjectClass(UPK_PalettTrigger, "UPK_PalettTrigger")
UniversalProcessKit.addModule("paletttrigger",UPK_PalettTrigger)
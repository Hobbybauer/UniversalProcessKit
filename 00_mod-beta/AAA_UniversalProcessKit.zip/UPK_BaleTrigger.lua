-- by mor2000

--------------------
-- BaleTrigger


local UPK_BaleTrigger_mt = ClassUPK(UPK_BaleTrigger,UniversalProcessKit)
InitObjectClass(UPK_BaleTrigger, "UPK_BaleTrigger")
UniversalProcessKit.addModule("baletrigger",UPK_BaleTrigger)